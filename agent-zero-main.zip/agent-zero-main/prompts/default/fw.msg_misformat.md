~~~json
{
    "system_warning": "You have misformatted your message. Follow system prompt instructions on JSON message formatting precisely."
}
~~~