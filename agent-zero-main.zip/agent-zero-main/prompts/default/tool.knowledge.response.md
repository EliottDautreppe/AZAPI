~~~json
{
    "online_sources": "{{online_sources}}",
    "memory": "{{memory}}",
}
~~~