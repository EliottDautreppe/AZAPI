~~~json
{
    "memory": "Memory has been saved with id {{memory_id}}."
}
~~~